let count=0;
console.log('start count= ', count);

let ask=prompt('1. Скільки океанів налічує Земля?');
if (ask=='5') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
} 
let ask2=prompt('2. Природний водний потік, який починається з витоку, тече у виробленому ним самим заглибленні і закінчується гирлом – це…')
if (ask2=='річка' || ask2=='Річка') {
    console.log('Відповідь вірна'); 
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask3=prompt('3. Яка країна не має виходу до моря Узбекистан, Японія чи Пакистан?');
if (ask3=='Узбекистан' || ask3=='узбекистан') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask4=prompt('4. Яка країна розташована у двох частинах світу Туреччина, Мексика чи Україна?')
if (ask4=='туреччина' || ask4=='Туреччина') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask5=prompt('5. Яка станція метро в столиці України знаходиться на глибині 105 м під землею і є найглибшою в світі?')
if (ask5=='Арсенальна' || ask5=='арсенальна') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask6=prompt('6. Яке місце посідає Україна у світі за кількістю людей з вищою освітою?')
if (ask6=='4') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask7=prompt('7. Який український музичний інструмент є найдовшим у світі?')
if (ask7=='Трембіта' || ask7=='трембіта') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask8=prompt('8. Яке місце у світовому рейтингу має Україна з виробництва меду на одну людину?')
if (ask8=='1') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask9=prompt('9. У якому році всесвітньовідоме видання The New York Times назвало українську вишивку головним трендом літнього сезону?')
if (ask7=='2016') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
let ask10=prompt('10. У якому місті України зберігається унікальний надзвуковий стратегічний бомбардувальник ТУ-160, якого немає в інших музеях світу?')
if (ask10=='Полтава' || ask10=='полтава') {
    console.log('Відповідь вірна');
    count++;
}
else if(ask==null){
    console.log('Відповідь неправильна');
}
else if(ask==''){
    console.log('Відповідь неправильна');
}
else {
    console.log('Відповідь неправильна');
}
console.log(count);