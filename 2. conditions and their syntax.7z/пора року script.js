let season=prompt('Write the number');
if (season>=1 && season<=2){
    console.log('Зима');
}
else if (season>=3 && season<=5){
    console.log('Весна');
}
else if (season>=6 && season<=8){
    console.log('Літо');
}
else if (season>=9 && season<=11){
    console.log('Осінь');
}
else if (season==12){
    console.log('Зима');
}
else {
    console.log('Введіть число від 1 до 12');
}