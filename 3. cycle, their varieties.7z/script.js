// Завдання 1
// for (let z=1000; z<=9999; z+=3){
//     document.write(`<h4>Loop ${z}</h4>`);
// }

// Завдання 2
// let num=1;
// for(let k=1; k<=55; k++){
//     document.write(`<h4>Loop ${num}</h4>`);
//     num+=5;
// }

// Завдання 3
// for (let z=90; z>=0; z-=5){
//     document.write(`<h4>Loop ${z}</h4>`);
// }

// Завдання 4
let num1=2;
let num2=2;
let result=1;
for(let i=1; i<=20; i++){
    result=result*num2;
    document.write(`<h4>Loop ${result}</h4>`);
}