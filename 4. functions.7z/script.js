// Завдання 1 
// let number=prompt('write number');
// switch (number) {
//     case '12':
//         console.log('Зима');
//         break;
//     case '1':
//     case '2':
//         console.log('Зима');
//         break;
//     case '3':
//     case '4':
//     case '5':
//         console.log('Весна');
//         break;
//     case '6':
//     case '7':
//     case '8':
//         console.log('Літо');
//         break;
//     case '9':
//     case '10':
//     case '11':
//         console.log('Осінь');
//         break;
//     default:
//         console.log('wrong number')
//         break;
// }

// Завдання 2
// function number(a){
//     if (a%2==0){
//         return('парне');
//     }
//     if (a%2==1){
//         return('непарне');
//     }
//     else if (a==0){
//         return('нуль');
//     }
// }
// let data=number ('6');
// console.log(data);

// Завдання 3
function operat(a, b, s){
    if (s=='+'){
       return a+b;
    }
    if (s=='-'){
       return a-b;
    }
    if (s=='*'){
        return a*b;
    }
    if (s=='/'){
         return a/b;
    }
}
let dat=operat (2, 3,'+');
let dat2=operat (10, 3,'-');
let dat3=operat (4, 3,'*');
let dat4=operat (10, 2,'/');
console.log(dat);
console.log(dat2);
console.log(dat3);
console.log(dat4);

// var s=function(x,y){return x+y;};
// console.log( s(2,3));