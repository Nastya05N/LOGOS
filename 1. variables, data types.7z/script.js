// Завдання 1
// let city = 'Київ';
// console.log(city);
// city = 'Львів';
// console.log(city);
// let adress = city;
// alert (adress);

// Завдання 2
// let n = 5;
// let result = Math.pow (n, 3);
// console.log(result);

// Завдання 3
// let pen = 4;
// let pricen = 5.25;
// let pencil = 6;
// let pricel = 3.50;
// let prodn = pen*pricen;
// let prodl = pencil*pricel;
// let sum = prodn + prodl;
// document.write(sum);

// Or завдання 3
let pen = 4;
let pricen = 5.25;
let pencil = 6;
let pricel = 3.50;
let sum = (pen*pricen) + (pencil*pricel);
document.write(sum);